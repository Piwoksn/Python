def large(a):
    max = 0
    for item in a:
        num = int(item)
        if num > max:
            max = num
            
    print(f'Largest Number: {max}')