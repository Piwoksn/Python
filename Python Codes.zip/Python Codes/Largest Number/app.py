import largest as l

def reuse():
    num = input('Enter Set of Numbers: ').split()
    l.large(num)
    
    
reuse()

