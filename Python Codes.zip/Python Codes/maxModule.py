
def maximum():
    list = input('Enter list of Numbers: ').split()

    max = 0
    for item in list:
        num = int(item)
        if num > max:
            max = num
            
    print(max)
    
    
maximum()

maximum()

