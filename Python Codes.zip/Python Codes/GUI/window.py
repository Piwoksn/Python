from tkinter import *


window = Tk()
window.config(background= 'pink')
#window.geometry('420x420')




window.mainloop()