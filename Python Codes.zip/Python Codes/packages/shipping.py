def free_shipping():
    print('Freely Shipped')