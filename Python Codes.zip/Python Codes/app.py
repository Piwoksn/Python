import packages.shipping
from packages import shipping
from packages.shipping import free_shipping
from dice import Dice


packages.shipping.free_shipping()
shipping.free_shipping()
free_shipping()


dice = Dice()
dice.roll()
dice.roll()
dice.roll()