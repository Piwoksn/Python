import converter as c

def reuse():
    a = int(input('> '))
    
