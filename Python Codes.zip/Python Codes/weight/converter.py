class Class:
    def __init__(self, weight):
        self.weight = weight
        
    def kg_to_lb(self):
        w = self.weight / 0.45
        print(f'\nweight = {w} pounds')
    
    def lb_to_kg(self):
        w = self.weight * 0.45
        print(f'\nweight = {w} Kilogram')

