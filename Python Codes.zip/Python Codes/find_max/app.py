from util import find_max as f

def reuse():
    num = input('> ').split()
    f(num)
    
    
reuse()
reuse()