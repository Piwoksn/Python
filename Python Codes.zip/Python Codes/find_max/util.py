
def find_max(num):
    output = 0
    for item in num:
        n = int(item)
        if output < n:
            output = n
            
    print(f'max = {output}')
    
    

    