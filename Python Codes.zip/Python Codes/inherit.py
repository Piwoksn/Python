class Person:
    def __init__(self):
        name = input('Name: ')
        self.name = name
        
    def talk(self):
       print(f'{self.name} is talking')
       
    def move(self):
       print(f'{self.name} is Moving')
       
       
guy = Person()

guy.talk()
guy.move()
print()


class Hobby(Person):
    def dance(self):
        print(f'{self.name} is dancing')
        
    def read(self):
         print(f'{self.name} is reading')



class Test:
    def test(self):
        print('Tested')
    
    
print()
class Girl(Hobby, Test):
    pass
    
    
gal = Girl()
gal.talk()
gal.move()
gal.dance()
gal.read()
gal.test()