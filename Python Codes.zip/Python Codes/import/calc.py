import code

option = input('add or mult: ').lower()
if option == "add":
    a = int(input('a = '))
    code.add(a)
else:
    a = int(input('a = '))
    code.mult(a)