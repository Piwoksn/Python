def add(a):
    sum = a + a
    print(sum)
    
    
def mult(a):
    mult = a * a
    print(mult)
    
