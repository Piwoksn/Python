import time
class Quest:
      questions = {
        'What is my name?': 'A',
        'How old am I?': 'C',
        'What is my level of Education?': 'C',
        'What school did I attain my PGDE?':'A',
        'What year was I born?':'B',
        'What date was i born?':'C',
        'What is my hobby?':'C'
    }

      options = [
        ['(A) Noble Piwoks', '(B) Monday Obi', '(C) Michael Luis'],
        ["(A) 21", "(B) 23", "(C) 28"],
        ['(A) Waec', '(B) Bsc', '(C) M.Sc'],
        ['(A)IAUE', '(B) UST', '(C) Uniport'],
        ['(A)1994', '(B)1995', '(C)1996'],
        ['(A) 30th January', '(B) 21st January','(C) 31st January'],
        ['(A) Eating', '(B) Coding', '(C) All of the above']
    ]


def result(Pass, Fail):
    print('RESULT')
    print('--------------------')
    print("You Passed = " + str(Pass))
    print("You Failed = " + str(Fail)+'\n')

#---------------------

def replay(response):
    while True:
        if response != 'YES' and response != 'NO':
            response = input('\nWant to Replay?: (Yes or No) ').upper()
        else:
            if response == 'YES':
                print()
                print('-----RESTARTING----')
                print()
                start_exam(quest)
                break
            elif response == 'NO':
                print('Byee')
                break






#____________________


def start_exam(quest):
    
#Items
    computer = []

    Pass = 0
    Fail = 0

    count = 1
    player_answer = []

#Question checkers
    for key in quest.questions:
        print(key)
        for option in quest.options[count -1]:
            print(option, end=" ")

#Player Resonse
        player = input("\nChoose option A, B, C?: ").upper()
        while True:
            if player != 'A' and player != 'B' and player != 'C':
                player = input("\nChoose option A, B, C?: ").upper()

            else:
                break

#Question and Response Checker
        if player == quest.questions.get(key):
            print('Correct')
            Pass+=1
        else:
            print('Wrong')
            Fail+=1

        player_answer.append(player)
        print('----------------------')
        count+=1
        #time.sleep(1)
    print()

#SCore Board
    result(Pass, Fail)
    average = int(Pass / len(quest.questions) * 100)
    print(f"Average Score =  {average}%")
    print("Your answers are: "+ str(player_answer))
    
    for key,values in quest.questions.items():
        computer.append(values)
    
    print("Correct answers are: "+str(computer))

#Replay
    response = input('\nWant to Replay?: (Yes or No) ')
    response = response.upper()
    replay(response)
    print()






quest = Quest()

start_exam(quest)






#----------------------

