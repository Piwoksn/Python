import random

class Dice:
    def roll(self):
        a = random.randint(0, 9)
        b = random.randint(0, 9)
        
        roll = (a, b)
        print(roll)
        
 

