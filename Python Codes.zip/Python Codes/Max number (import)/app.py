import util
from util import find_max

numbers = [2, 4, 8, 2, 10, 3]
maximum = util.find_max(numbers)
print(maximum)

"Part 2 with input"

list = input("Enter list of Number: ").split()
print(list)

list2 = []
for item in list:
    num = int(item)
    list2.append(num)
    

maximum2 = find_max(list2)
    
    
print(maximum2)