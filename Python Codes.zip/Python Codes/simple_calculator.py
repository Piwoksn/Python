a = input('a = ')
b = input('b = ')
A = int(a)
B = int(b)

print('select: \n(A) for add\n(S) for Subtraction\n(D) for Division\n(M) for Multipication')
print()
select = input('> ')

if select.upper() == 'A':
    c = A + B
    print(f'Sum = {c}')
    
if select.upper() == 'S':
    c = A - B
    print(f'Score = {c}')
    
if select.upper() == 'D':
    c = A / B
    print(f'Score = {c}')
    
if select.upper() == 'M':
    c = A * B
    print(f'Score = {c}')